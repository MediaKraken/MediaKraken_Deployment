libdiscid package
-----------------

:mod:`libdiscid` module
^^^^^^^^^^^^^^^^^^^^^^^

.. automodule:: libdiscid
   :members:

Classes
~~~~~~~

.. autoclass:: libdiscid.DiscId
   :show-inheritance:
   :members:

Exceptions
~~~~~~~~~~

.. autoexception:: libdiscid.DiscError
   :show-inheritance:
   :members:


Subpackages
^^^^^^^^^^^

.. toctree::

   api.compat
