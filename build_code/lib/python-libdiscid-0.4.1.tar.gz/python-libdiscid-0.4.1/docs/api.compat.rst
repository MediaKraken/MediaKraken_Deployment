libdiscid.compat package
^^^^^^^^^^^^^^^^^^^^^^^^

:mod:`discid` module
~~~~~~~~~~~~~~~~~~~~

The `discid` module provides the same interface as :py:mod:`discid`. Please
have a look at its `documentation`__.

.. __: https://python-discid.readthedocs.org/en/v1.0.2/api/
