BabelFish
=========

BabelFish is a Python library to work with countries and languages.

.. image:: https://travis-ci.org/Diaoul/babelfish.png?branch=master
    :target: https://travis-ci.org/Diaoul/babelfish

.. image:: https://coveralls.io/repos/Diaoul/babelfish/badge.png
    :target: https://coveralls.io/r/Diaoul/babelfish

License
-------

BabelFish is licensed under the `3-clause BSD license <http://opensource.org/licenses/BSD-3-Clause>`_.
Copyright (c) 2013, the BabelFish authors and contributors.
