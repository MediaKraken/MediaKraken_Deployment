import logging
import logging.handlers

#default_logger = logging.getLogger()
#default_logger.setLevel(logging.DEBUG)
#default_logger.setLevel(logging.INFO)
#
#log_syslog = logging.handlers.SysLogHandler('/dev/log')
#
#log_format = 'PYHDHR: %(levelname)s %(message)s'
#log_syslog.setFormatter(logging.Formatter(log_format))
#
#default_logger.addHandler(log_syslog)

