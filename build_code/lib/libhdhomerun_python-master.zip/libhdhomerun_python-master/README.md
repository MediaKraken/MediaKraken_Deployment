Python bindings for select APIs from SiliconDust's libhdhomerun.

To build the library for development work, run the following command:

$ python setup.py build_ext --inplace

Changelog:

Version 1.1.0:
- Various bug fixes
- lock API implemented

Version 1.0.0:
- Initial release
- get, set, and upgrade APIs implemented
