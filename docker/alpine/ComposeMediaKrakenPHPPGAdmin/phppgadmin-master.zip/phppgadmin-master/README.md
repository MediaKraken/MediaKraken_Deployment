# phppgadmin
the premier web-based administration tool for postgresql

This Fork has some community changes to enable:
- Php v7 
- Postgres 9.5 Support

