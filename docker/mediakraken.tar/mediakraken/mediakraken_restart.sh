./mediakraken_stop.sh
./mediakraken_start.sh
