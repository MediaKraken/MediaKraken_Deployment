docker run -v /var/run/docker.sock:/var/run/docker.sock mediakraken/mkdebug
sleep 30
./mediakraken_start.sh
