export HOST_IP=$HOST_IP && docker-compose up -d
