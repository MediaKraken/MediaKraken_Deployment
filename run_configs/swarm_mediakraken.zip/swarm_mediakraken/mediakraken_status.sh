#!/bin/sh
docker stack services mkstack