docker stack rm mkstack
