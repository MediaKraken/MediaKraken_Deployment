#!/bin/sh
docker stack rm mkstack